<?php
// created: 2019-09-05 15:47:55
$dictionary["frnt_fornitori_azienda"]["fields"]["frnt_fornitori_documenti_frnt_fornitori_azienda"] = array (
  'name' => 'frnt_fornitori_documenti_frnt_fornitori_azienda',
  'type' => 'link',
  'relationship' => 'frnt_fornitori_documenti_frnt_fornitori_azienda',
  'source' => 'non-db',
  'module' => 'frnt_fornitori_documenti',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_FRNT_FORNITORI_DOCUMENTI_FRNT_FORNITORI_AZIENDA_FROM_FRNT_FORNITORI_DOCUMENTI_TITLE',
);
