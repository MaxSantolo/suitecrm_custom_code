<?php
// created: 2018-10-31 11:25:22
$dictionary["Lead"]["fields"]["sr_servizi_richiesti_leads"] = array (
  'name' => 'sr_servizi_richiesti_leads',
  'type' => 'link',
  'relationship' => 'sr_servizi_richiesti_leads',
  'source' => 'non-db',
  'module' => 'sr_servizi_richiesti',
  'bean_name' => 'sr_servizi_richiesti',
  'side' => 'right',
  'vname' => 'LBL_SR_SERVIZI_RICHIESTI_LEADS_FROM_SR_SERVIZI_RICHIESTI_TITLE',
);
