<?php
$dashletData['DR_EventiDashlet']['searchFields'] = array (
  'date_entered' => 
  array (
    'default' => '',
  ),
  'date_modified' => 
  array (
    'default' => '',
  ),
  'assigned_user_id' => 
  array (
    'type' => 'assigned_user_name',
    'default' => 'MASSIMILIANO SANTOLO',
  ),
);
$dashletData['DR_EventiDashlet']['columns'] = array (
  'set_complete' => 
  array (
    'width' => '1%',
    'label' => 'LBL_LIST_CLOSE',
    'default' => true,
    'sortable' => false,
  ),
  'int_date_c' => 
  array (
    'type' => 'datetimecombo',
    'default' => true,
    'label' => 'LBL_INT_DATE',
    'width' => '10%',
    'name' => 'int_date_c',
  ),
  'name' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'tipo' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_TIPO',
    'width' => '5%',
    'name' => 'tipo',
  ),
  'status' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_STATUS',
    'width' => '5%',
    'name' => 'status',
  ),
  'sede' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_SEDE',
    'width' => '5%',
    'name' => 'sede',
  ),
  'dr_eventi_leads_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_DR_EVENTI_LEADS_FROM_LEADS_TITLE',
    'id' => 'DR_EVENTI_LEADSLEADS_IDB',
    'width' => '10%',
    'default' => true,
    'name' => 'dr_eventi_leads_name',
  ),
  'description' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '40%',
    'default' => true,
    'name' => 'description',
  ),
  'date_modified' => 
  array (
    'width' => '15%',
    'label' => 'LBL_DATE_MODIFIED',
    'name' => 'date_modified',
    'default' => false,
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
  'dr_eventi_accounts_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_DR_EVENTI_ACCOUNTS_FROM_ACCOUNTS_TITLE',
    'id' => 'DR_EVENTI_ACCOUNTSACCOUNTS_IDB',
    'width' => '10%',
    'default' => false,
    'name' => 'dr_eventi_accounts_name',
  ),
);
