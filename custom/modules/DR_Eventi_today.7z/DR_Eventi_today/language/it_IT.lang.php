<?php
// created: 2018-09-25 15:11:08
$mod_strings = array (
  'LBL_STATUS' => 'Stato',
  'LBL_ESITO' => 'Esito / Risposta',
  'LNK_NEW_RECORD' => 'Crea Evento Reception',
  'LNK_LIST' => 'Visualizza Eventi Reception',
  'LNK_IMPORT_DR_EVENTI' => 'Importa Eventi Reception',
  'LBL_LIST_FORM_TITLE' => 'Evento Reception Lista',
  'LBL_SEARCH_FORM_TITLE' => 'Search Evento Reception',
  'LBL_HOMEPAGE_TITLE' => 'Eventi Reception',
  'LBL_INT_DATE' => 'Data evento',
  'LBL_DR_EVENTI_LEADS_FROM_LEADS_TITLE' => 'Contatto',
  'LBL_DR_EVENTI_SR_SERVIZI_RICHIESTI_FROM_SR_SERVIZI_RICHIESTI_TITLE' => 'Commerciale - Servizio Richiesto',
  'LBL_DR_EVENTI_ACCOUNTS_FROM_ACCOUNTS_TITLE' => 'Azienda',
  'LBL_DR_EVENTI_DOCUMENTS_1_FROM_DOCUMENTS_TITLE' => 'Allegati',
  'LBL_LIST_CLOSE' => 'Chiudi',
);